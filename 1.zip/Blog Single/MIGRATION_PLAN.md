
# Website Consolidation Plan

## Current Structure Analysis

### Folders to Consolidate:
1. Home Page (MAIN - Keep this)
2. about
3. Blog Single
4. Blogs
5. Contact Page
6. Doctor Single
7. Doctors
8. FAQ
9. Service Left
10. Service Right
11. Service Single
12. Services
13. Testimonials
14. 404

## Phase 1: Analysis ✓

### Assets Analysis:
- **CSS/JS Files**: All folders have IDENTICAL plugin files (can use one copy)
- **main.css/main.js**: Likely identical across folders
- **Images**: Each folder has SOME unique images in subfolders
- **Fonts**: Identical across all folders

### Duplicate Handling Strategy:
1. **Identical files** (CSS, JS, fonts): Keep only ONE copy in Home Page/assets
2. **Images with same names**: 
   - Check if identical (keep one)
   - If different: Rename with prefix (e.g., about-img1.png, contact-img1.png)

## Phase 2: Create Backup (NEXT)
- Copy entire "Blog Single" folder as backup

## Phase 3: Consolidate Assets
- Move unique images from each folder to Home Page/assets/img
- Handle duplicate image names
- Keep only one copy of CSS/JS files

## Phase 4: Move HTML Files
- Move all HTML files to Home Page folder
- Rename if needed (e.g., about.html stays as about.html)

## Phase 5: Update Paths
- Update all asset paths in HTML files to point to consolidated assets folder

## Phase 6: Testing & Cleanup
- Verify all pages load correctly
- Delete empty folders

---

## Files Requiring Special Attention:

### Unique Images Found:
- about folder: elements28.png, elements9.png, contact subfolder
- Home Page: hero subfolder, service subfolder, blog subfolder

### HTML Files to Move:
- about.html (from about folder)
- blog-single.html (from Blog Single folder)
- blog.html (from Blogs folder)
- contact.html (from Contact Page folder)
- doctor-single.html (from Doctor Single folder)
- doctor.html (from Doctors folder)
- faq.html (from FAQ folder)
- service-left.html (from Service Left folder)
- service-right.html (from Service Right folder)
- service-single.html (from Service Single folder)
- service.html (from Services folder)
- testimonial.html (from Testimonials folder)
- 404.html (from 404 folder)

---

## Status: Phase 1 Complete ✓
## Status: Phase 2 Complete ✓ - Backup created at "Blog Single_BACKUP"
## Status: Phase 3 Complete ✓ - Assets Consolidated
## Status: Phase 4 Complete ✓ - All HTML Files Moved:
  ✓ about.html
  ✓ blog-single.html
  ✓ blog.html
  ✓ contact.html
  ✓ doctor-single.html
  ✓ doctor.html
  ✓ faq.html
  ✓ service-left.html
  ✓ service-right.html
  ✓ service-single.html
  ✓ service.html
  ✓ testimonial.html
  ✓ 404.html
## Status: Phase 5 Complete ✓ - Asset Paths Already Correct!
  - All HTML files already use correct paths: assets/img/, assets/css/, assets/js/
  - No path updates needed - files were already properly structured
## Status: Phase 6 Complete ✓ - Testing & Cleanup Done!
  - Deleted all empty folders (404, about, Blog Single, Blogs, Contact Page, Doctor Single, Doctors, FAQ, Service Left, Service Right, Service Single, Services, Testimonials)
  - Final structure: All HTML files and consolidated assets now in "Home Page" folder
  - Backup remains at "Blog Single_BACKUP" (in parent directory)

## ✅ MIGRATION COMPLETE!
### Final Structure:
- **Home Page/** - Contains all 14 HTML files and consolidated assets
- **MIGRATION_PLAN.md** - This documentation
- All pages ready for testing - open any HTML file in browser
